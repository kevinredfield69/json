# -*- coding: utf-8 -*-

import json
with open('resumen-accidentes-2015.json') as data_file:
    data = json.load(data_file)

lista=[]

for accidente in data:
    lista.append(accidente["MES"])

print "El Mes De Enero De 2015 Tuvo",lista.count(1),"Accidentes Totales."
print "El Mes De Febrero De 2015 Tuvo",lista.count(2),"Accidentes Totales."
print "El Mes De Marzo De 2015 Tuvo",lista.count(3),"Accidentes Totales."
print "El Mes De Abril De 2015 Tuvo",lista.count(4),"Accidentes Totales."
print "El Mes De Mayo De 2015 Tuvo",lista.count(5),"Accidentes Totales."
print "El Mes De Junio De 2015 Tuvo",lista.count(6),"Accidentes Totales."
print "El Mes De Julio De 2015 Tuvo",lista.count(7),"Accidentes Totales."
print "El Mes De Agosto De 2015 Tuvo",lista.count(8),"Accidentes Totales."
print "El Mes De Septiembre De 2015 Tuvo",lista.count(9),"Accidentes Totales."
print "El Mes De Octubre De 2015 Tuvo",lista.count(10),"Accidentes Totales."
print "El Mes De Noviembre De 2015 Tuvo",lista.count(11),"Accidentes Totales."
print "El Mes De Diciembre De 2015 Tuvo",lista.count(12),"Accidentes Totales."




