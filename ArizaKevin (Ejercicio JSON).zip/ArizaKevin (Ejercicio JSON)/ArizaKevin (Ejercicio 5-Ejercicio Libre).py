# -*- coding: utf-8 -*-

import json
with open('resumen-accidentes-2015.json') as data_file:
    data = json.load(data_file)

mes=int(raw_input("Introducir Número De Mes: "))
ilesos=raw_input("Introducir Número De Ilesos: ")

if mes < 1 or mes > 12:
    print ""
    print "El mes introducido es incorrecto. Por favor, vuelve a ejecutar el programa."
else:
    print ""
    print "LISTA DE ACCIDENTES PRODUCIDOS EN EL MES",mes,"DE ACUERDO A",ilesos,"ILESOS EN ESPAÑA EN 2015."
    for accidente in data:
        if accidente["MES"] == mes:
            if accidente["ILESOS"] == ilesos:
                print ""
                print "Fecha:",accidente["FECHA"]
                print "Hora:",accidente["HORA"]

                if accidente["LEVES"] and accidente["GRAVES"] == "0":
                    print "No ha habido ilesos leves y graves"
                else:
                    if accidente["LEVES"] == "0":
                        print "No ha habido ilesos leves"
                    else:
                        print "Personas con lesiones leves:",accidente["LEVES"]
                    if accidente["GRAVES"] == "0":
                        print "No ha habido ilesos graves"
                    else:
                        print "Personas con lesiones graves:",accidente["GRAVES"]